# Project Documentation Entry Point #

1. [Team Members and Tasks Distribution](TeamMembersAndTasks.md)
2. [Markdown and UML templates for project documentation]((templates)/)