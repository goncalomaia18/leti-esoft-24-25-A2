#include <iostream>

using namespace std;

int main() {
    std::wcout << L"Console Application!" << std::endl;
    return 0;
}